const socket=io();
const $=(s)=>document.querySelector(s);const $$=(s)=>[...document.querySelectorAll(s)];
const fmtPts=(n)=>new Intl.NumberFormat('pt-BR').format(Number(n||0));
const fmtMs=(n)=>n==null?'—':(n/1000).toFixed(2)+'s';
function esc(s){return String(s??'').replace(/[&<>"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));}
function rankingHtml(rows,limit=10){return (rows||[]).slice(0,limit).map((r,i)=>`<div class="rank-row"><strong>${i+1}º</strong><b>${esc(r.nickname)}</b><span>${fmtPts(r.points)} pts</span></div>`).join('')||'<p class="sub">Ainda ninguém pontuou.</p>'}
